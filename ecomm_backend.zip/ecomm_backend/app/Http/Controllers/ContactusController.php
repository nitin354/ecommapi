<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Contactus;

class ContactusController extends Controller
{
    //
    function contactus(Request $req){

        $contact = new Contactus;

        $contact->name = $req->input('name');
        $contact->email = $req->input('email');
        $contact->message = $req->input('message');
        $contact->save();
        print_r(
            DB::connection('my_connection')->getQueryLog()
         );

    	return $contact;
    }
    
}
